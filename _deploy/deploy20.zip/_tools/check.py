#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成物の検証：リンク切れ / 目次アンカー / コマンドのコメント率。"""
import re, pathlib, urllib.parse, sys

# このスクリプトは _tools/ の中に置かれている前提。検査対象はリポジトリのルート。

FENCE = re.compile(r"```.*?```", re.S)
INLINE = re.compile(r"`[^`\n]+`")

def slug(h):
    """GitHub（github-slugger）と同じ順序で見出しをアンカーに変換する。

    github-slugger は「trim → 記号を除去 → 残った空白を - に置換」の順で処理する。
    先に trim するため、記号を消した結果できた先頭の空白は - として残る。
    """
    s = h.strip().lower()                                   # ① 先に前後の空白を落とす
    s = re.sub(r"[`*_\[\]()（）「」。、:：/\\.,!?'\"]", "", s)  # ② 記号を落とす
    return s.replace(" ", "-")                              # ③ 残った空白を - にする

root = pathlib.Path(__file__).resolve().parent.parent   # _tools の 1 つ上
bad, anchor_bad, miss_lines = [], [], []

SKIP = {"_tools", "_deploy", "_to_delete"}   # 検査しないフォルダ


def target_files():
    """検査対象の md を返す（作業用フォルダは除く）。"""
    return [p for p in sorted(root.rglob("*.md"))
            if not (SKIP & set(p.relative_to(root).parts))]


for md in target_files():
    raw = md.read_text(encoding="utf-8")
    nofence = FENCE.sub("", raw)                      # コードブロックは検査対象外
    txt = INLINE.sub("", nofence)                     # リンク検査ではインラインコードも外す
    for m in re.finditer(r"\]\((?!https?://|mailto:|#)([^)]+)\)", txt):
        p = urllib.parse.unquote(m.group(1).split("#")[0])
        if p and not (md.parent / p).exists():
            bad.append((md.name, p))
    # 見出しはインラインコードを残したまま slug 化する（GitHub と同じ入力にするため）
    heads = {slug(h) for h in re.findall(r"^#{2,4} (.+)$", nofence, re.M)}
    miss = {a for a in re.findall(r"\]\(#([^)]+)\)", txt)} - heads
    if miss:
        anchor_bad.append((md.name, miss))

print("リンク切れ:", bad or "なし")
print("目次アンカー不整合:", anchor_bad or "なし")
print()
for f in target_files():
    if f.name == "README.md":
        continue
    lines = f.read_text(encoding="utf-8").split("\n")
    tot = nc = 0
    in_bash = False                                   # ```bash の中だけを検査対象にする
    for l in lines:
        s = l.strip()
        if s.startswith("```"):
            in_bash = s in ("```bash", "```sh") if not in_bash else False
            continue
        if in_bash and s.startswith("$ ") and not s.startswith("$ ..."):
            tot += 1
            if "#" not in l and not l.rstrip().endswith("\\"):
                nc += 1
                miss_lines.append((f.name, lines.index(l) + 1, s[:70]))
    print(f"{f.name:36s} {len(lines):5d}行  コマンド{tot:4d}  コメント無し{nc:3d}")

if miss_lines:
    print("\n=== コメントの無いコマンド行 ===")
    for name, ln, s in miss_lines:
        print(f"  {name}:{ln}  {s}")

sys.exit(1 if bad or anchor_bad else 0)
